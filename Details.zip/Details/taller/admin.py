from django.contrib import admin
from .models import *


# Register your models here.
models = [Clientes, CondicionesIva, DetallesFacturas, Facturas, FormasPago, Productos, Tiposp]

admin.site.register(models)

