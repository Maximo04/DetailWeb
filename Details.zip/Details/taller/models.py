# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Clientes(models.Model):
    cod_cliente = models.IntegerField(db_column='COD_CLIENTE', primary_key=True)  # Field name made lowercase.
    apellido = models.CharField(db_column='APELLIDO', max_length=30, blank=True, null=True)  # Field name made lowercase.
    nombre = models.CharField(db_column='NOMBRE', max_length=30, blank=True, null=True)  # Field name made lowercase.
    telefono = models.DecimalField(db_column='TELEFONO', max_digits=10, decimal_places=0, blank=True, null=True)  # Field name made lowercase.
    cod_condicion_iva = models.ForeignKey('CondicionesIva', models.DO_NOTHING, db_column='COD_CONDICION_IVA', blank=True, null=True)  # Field name made lowercase.
    cuit = models.DecimalField(db_column='CUIT', max_digits=10, decimal_places=0, blank=True, null=True)  # Field name made lowercase.
    deudor = models.CharField(db_column='DEUDOR', max_length=1, blank=True, null=True)  # Field name made lowercase.
    email = models.CharField(db_column='EMAIL', max_length=75, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'CLIENTES'


class CondicionesIva(models.Model):
    cod_condicion_iva = models.IntegerField(db_column='COD_CONDICION_IVA', primary_key=True)  # Field name made lowercase.
    descripcion = models.CharField(db_column='DESCRIPCION', max_length=30, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'CONDICIONES_IVA'


class DetallesFacturas(models.Model):
    cod_detalle = models.IntegerField(db_column='COD_DETALLE', primary_key=True)  # Field name made lowercase.
    cod_producto = models.ForeignKey('Productos', models.DO_NOTHING, db_column='COD_PRODUCTO', blank=True, null=True)  # Field name made lowercase.
    cantidad = models.IntegerField(db_column='CANTIDAD', blank=True, null=True)  # Field name made lowercase.
    nro_factura = models.ForeignKey('Facturas', models.DO_NOTHING, db_column='NRO_FACTURA', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'DETALLES_FACTURAS'


class Facturas(models.Model):
    nro_factura = models.IntegerField(db_column='NRO_FACTURA', primary_key=True)  # Field name made lowercase.
    fecha = models.DateField(db_column='FECHA', blank=True, null=True)  # Field name made lowercase.
    cod_forma_pago = models.ForeignKey('FormasPago', models.DO_NOTHING, db_column='COD_FORMA_PAGO', blank=True, null=True)  # Field name made lowercase.
    cod_cliente = models.ForeignKey(Clientes, models.DO_NOTHING, db_column='COD_CLIENTE', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'FACTURAS'


class FormasPago(models.Model):
    cod_forma_pago = models.IntegerField(db_column='COD_FORMA_PAGO', primary_key=True)  # Field name made lowercase.
    descripcion = models.CharField(db_column='DESCRIPCION', max_length=30, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'FORMAS_PAGO'


class Productos(models.Model):
    cod_producto = models.IntegerField(db_column='COD_PRODUCTO', primary_key=True)  # Field name made lowercase.
    descripcion = models.CharField(db_column='DESCRIPCION', max_length=20, blank=True, null=True)  # Field name made lowercase.
    cod_tipo_p = models.ForeignKey('Tiposp', models.DO_NOTHING, db_column='COD_TIPO_P', blank=True, null=True)  # Field name made lowercase.
    precio = models.DecimalField(db_column='PRECIO', max_digits=8, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    stock = models.IntegerField(db_column='STOCK', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'PRODUCTOS'


class Tiposp(models.Model):
    cod_tipo_p = models.IntegerField(db_column='COD_TIPO_P', primary_key=True)  # Field name made lowercase.
    nombre = models.CharField(db_column='NOMBRE', max_length=30, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'TIPOSP'
