# Create your views here.
from django.views.generic import *
from django.shortcuts import render
from .models import *
import os
from .forms import *
# Create your views here.

class ProductoListView(ListView):
    model = Productos
    template_name = 'taller/products.html'

class RedireccionarView(RedirectView):
    url = '/' #url tiene mas prioridad
    url2 = '/Producto'
    #se podria hacer logica
    def get_redirect_url(self, *args, **kwargs):
        # Podemos hacer lógica antes que redireccione
        print("Guardado")
        return super().get_redirect_url(*args, **kwargs)
def index(request):

    productos = Productos.objects.all()
    context = {'all': productos}

    return render(request, 'taller/index.html', context)
def hijo(request):
    return render(request, 'hijo.html')
class DetalleView(DetailView):
    model = Productos
    template_name = 'taller/detail.html'
    #slug_field = 'descripcion'
    context_object_name = 'Productos'

class ProductoListView(ListView):
    model = Productos
    template_name = 'taller/producto_listview.html'
    context_object_name = 'producto'

class ProductoFormView(FormView):

    template_name = 'taller/producto_formview.html'
    form_class = ProductoForm
    success_url = '/Productos'
    def form_valid(self, form):
        print("Formulario Válido")
        form.save()
        return super(ProductoFormView, self).form_valid(form)
    def form_invalid(self, form):
        print("Formulario Inválido")
        return super(ProductoFormView, self).form_invalid(form)


class ProductoCreateView(CreateView):
    template_name = 'taller/producto_formview.html'
    model = Productos
    fields = ('cod_producto', 'descripcion', 'precio', 'stock')
    # fields = '__all__'
    success_url = '/'

def form_valid(self, form):
    #formulario es válido
    print("Formulario Válido :)")
    return super(ProductoCreateView, self).form_valid(form)

def form_invalid(self, form):
    #formulario es inválido
    print("Formulario Inválido :(")
    return super(ProductoCreateView, self).form_invalid(form)
class ProductoUpdateView(UpdateView):

    template_name = 'taller/producto_formview.html'
    model = Productos
    fields = '__all__'

    success_url = ''

    def get_success_url(self):
        return self.request.path
class ProductoDeleteView(DeleteView):

    template_name = 'taller/producto_formdelete.html'
    model = Productos
    success_url = '/'

    context_object_name = 'Producto'
