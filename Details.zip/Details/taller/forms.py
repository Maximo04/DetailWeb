from django.forms import ModelForm
from .models import *

class ProductoForm(ModelForm):

    class Meta:
        model = Productos
        fields = '__all__'