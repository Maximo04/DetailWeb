from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('Producto/<pk>', views.DetalleView.as_view(), name="Detalle"),
    path('ProductoCreate', views.ProductoCreateView.as_view(), name="Crear"),
    path('ProductoUpdate/<pk>', views.ProductoUpdateView.as_view(), name="Editar"),
    path('ProductoDelete/<pk>', views.ProductoDeleteView.as_view(), name="Borrar"),
    path('hijo/', views.hijo)
]